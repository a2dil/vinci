package model;

public class Type_Page {
	private int id_type_page ;
	private int id_document;
	private char path_page ;
	public Type_Page() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId_type_page() {
		return id_type_page;
	}
	public void setId_type_page(int id_type_page) {
		this.id_type_page = id_type_page;
	}
	public int getId_document() {
		return id_document;
	}
	public void setId_document(int id_document) {
		this.id_document = id_document;
	}
	public char getPath_page() {
		return path_page;
	}
	public void setPath_page(char path_page) {
		this.path_page = path_page;
	}

}
