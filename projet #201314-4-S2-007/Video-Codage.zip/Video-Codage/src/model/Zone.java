package model;

public class Zone {
	private int id_zone;
	private int id_contenu;
	private char type_zone ;
	private char zone;
	public Zone() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId_zone() {
		return id_zone;
	}
	public void setId_zone(int id_zone) {
		this.id_zone = id_zone;
	}
	public int getId_contenu() {
		return id_contenu;
	}
	public void setId_contenu(int id_contenu) {
		this.id_contenu = id_contenu;
	}
	public char getType_zone() {
		return type_zone;
	}
	public void setType_zone(char type_zone) {
		this.type_zone = type_zone;
	}
	public char getZone() {
		return zone;
	}
	public void setZone(char zone) {
		this.zone = zone;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getX2() {
		return x2;
	}
	public void setX2(int x2) {
		this.x2 = x2;
	}
	public int getY2() {
		return y2;
	}
	public void setY2(int y2) {
		this.y2 = y2;
	}
	private int x ;
	private int y ;
	private int x2 ;
	private int y2 ;
	

}
