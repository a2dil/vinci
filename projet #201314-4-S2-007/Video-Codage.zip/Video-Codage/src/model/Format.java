package model;

public class Format {
	private int id_format;
	private char type_format ;
	public Format() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId_format() {
		return id_format;
	}
	public void setId_format(int id_format) {
		this.id_format = id_format;
	}
	public char getType_format() {
		return type_format;
	}
	public void setType_format(char type_format) {
		this.type_format = type_format;
	}
	
	

}
